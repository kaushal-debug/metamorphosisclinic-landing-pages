<?php include 'header.php'; ?>
<main class="metamorphosisclinic-main-wrapper">
    <!-- ================= Hero Section START ================= -->
    <section class="hero-section"> 
        <div class="container">
            <div class="row">
                <div class="col-12 align-items-start site-logo-wrapper">
                    <a href="https://www.metamorphosis-clinic.com/" target="_blank" rel="noopener noreferrer" title="Metamorphosis Clinic">
                        <img src="assets/images/global/site-logo.png" alt="Site Logo" class="site-logo" width="160" height="60">
                    </a>
                </div>
            </div>
            <div class="row">
                <!-- Left Content -->
                <div class="col-lg-6 hero-content">
                    <div class="hero-text">
                        <h1 class="h1-title">
                            Smooth, Hair-Free Skin with Advanced 
                            <span>Laser Hair Reduction</span>
                        </h1>

                        <p class="sub-title">
                            Safe, painless & dermatologist-led laser hair removal 
                            across <strong>9 clinics in Mumbai & Delhi.</strong>
                        </p>
                        <div class="hero-features-wrapper">
                            <div class="hero-features">
                                <div class="feature-box">
                                    <div class="icon">
                                        <img src="assets/images/hero-badge-1.svg" alt="FDA-Approved Technology" width="35" height="35">
                                    </div>
                                    <p class="text">FDA-Approved Technology</p>
                                </div>
    
                                <div class="feature-box">
                                    <div class="icon">
                                        <img src="assets/images/hero-badge-2.svg" alt="Certified Experts" width="35" height="35">
                                    </div>
                                    <p class="text">Performed by certified experts</p>
                                </div>
    
                                <div class="feature-box">
                                    <div class="icon">
                                        <img src="assets/images/hero-badge-3.svg" alt="Suitable for All Skin Types" width="35" height="35">
                                    </div>
                                    <p class="text">Suitable for all skin types</p>
                                </div>
                            </div>
                            <div class="image-wrapper for-mobile">
                                <img src="assets/images/hero-section-image.png" alt="Laser Hair Reduction">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right Image -->
                <div class="col-lg-6 hero-image for-desktop">
                    <div class="image-wrapper">
                        <img src="assets/images/hero-section-image.png" alt="Laser Hair Reduction">
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- ================= Hero Section END ================= -->
    
    <?php include 'sections/section-contact.php'; ?>
    
    <!-- ================= before-after Section START ================= -->
    <section class="section before-after-section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    
                    <!-- Heading -->
                    <div class="section-header text-center">
                        <h2 class="h2-title">
                            <span>Real Results</span> You can See
                        </h2>
                        <p>Visible reduction in hair growth after just a few sessions</p>
                    </div>

                    <!-- Slider -->
                    <div class="swiper beforeAfterSwiper">
                        <div class="swiper-wrapper">

                            <!-- Slide 1 -->
                            <div class="swiper-slide">
                                <div class="before-after-card">
                                    
                                    <div class="image-box before">
                                        <img src="assets/images/before-after-images/slide-1-b.png" alt="before">
                                        <span>Before</span>
                                    </div>

                                    <div class="image-box after">
                                        <img src="assets/images/before-after-images/slide-1-a.png" alt="after">
                                        <span>After</span>
                                    </div>

                                </div>
                            </div>

                            <!-- Slide 2 -->
                            <div class="swiper-slide">
                                <div class="before-after-card">
                                    
                                    <div class="image-box before">
                                        <img src="assets/images/before-after-images/slide-2-b.png" alt="before">
                                        <span>Before</span>
                                    </div>

                                    <div class="image-box after">
                                        <img src="assets/images/before-after-images/slide-2-a.png" alt="after">
                                        <span>After</span>
                                    </div>

                                </div>
                            </div>
                             <!-- Slide 3 -->
                            <div class="swiper-slide">
                                <div class="before-after-card">
                                    
                                    <div class="image-box before">
                                        <img src="assets/images/before-after-images/slide-1-b.png" alt="before">
                                        <span>Before</span>
                                    </div>

                                    <div class="image-box after">
                                        <img src="assets/images/before-after-images/slide-1-a.png" alt="after">
                                        <span>After</span>
                                    </div>

                                </div>
                            </div>
                            <!-- Slide 4  -->
                            <div class="swiper-slide">
                                <div class="before-after-card">
                                    
                                    <div class="image-box before">
                                        <img src="assets/images/before-after-images/slide-2-b.png" alt="before">
                                        <span>Before</span>
                                    </div>

                                    <div class="image-box after">
                                        <img src="assets/images/before-after-images/slide-2-a.png" alt="after">
                                        <span>After</span>
                                    </div>

                                </div>
                            </div>

                        </div>

                        <!-- Navigation -->
                        <div class="slider-nav">
                            <div class="swiper-button-prev"></div>
                            <div class="swiper-button-next"></div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- ================= before-after Section END ================= -->

    <?php include 'sections/how-it-works-v1.php'; ?>
    <?php include 'sections/how-it-works-v2.php'; ?>

    <!-- ================= Why Section START ================= -->
    <section class="why-section section">
        <div class="container">
            
            <h2 class="why-title">
                Why Choose <span class="pink-text">Metamorphosis Clinic?</span>
            </h2>

            <div class="row align-items-center">
                
                <!-- Image -->
                <div class="col-md-6 listt1">
                    <div class="why-img">
                        <img src="./assets/images/Why-Choose-Mt-Clinic-Image.webp" alt="Clinic Team">
                    </div>
                </div>

                <!-- Content -->
                <div class="col-md-6 listt2">
                    <div class="why-list">

                        <div class="why-item">
                            <img class="check-box" src="./assets/images/why-choose-right.svg" alt="Clinic Team">
                            <div>
                                <strong>9 premium clinics</strong> across 
                                <span class="why-highlight pink-text">Mumbai & Delhi</span>
                            </div>
                        </div>

                        <div class="why-item">
                            <img class="check-box" src="./assets/images/why-choose-right.svg" alt="Clinic Team">
                            <div>
                                <strong>Dermatologist-supervised treatments</strong>
                            </div>
                        </div>

                        <div class="why-item">
                            <img class="check-box" src="./assets/images/why-choose-right.svg" alt="Clinic Team">
                            <div>
                                <strong>Advanced laser machines</strong> (latest technology)
                            </div>
                        </div>

                        <div class="why-item">
                            <img class="check-box" src="./assets/images/why-choose-right.svg" alt="Clinic Team">
                            <div>
                                <strong>Hygienic & safe</strong> environment
                            </div>
                        </div>

                        <div class="why-item">
                            <img class="check-box" src="./assets/images/why-choose-right.svg" alt="Clinic Team">
                            <div>
                                <strong>Customized plans</strong> for every skin type
                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </section>
    <!-- ================= Why Section  START ================= -->

    <?php include 'sections/packages-v1.php';?>
    <?php include 'sections/packages-v2.php';?>

    <!-- ================= testimonial Section START ================= -->
    <section class="testimonial-section section">
        <div class="container">
            <div class="row align-items-center">

                <!-- Left Content -->
                <div class="col-12">
                    <div class="testimonial-content  text-center">
                        <h2 class="h2-title">What Our <span>Clients Say</span></h2>
                    </div>
                </div>

                <!-- Right Slider -->
                <div class="col-12">
                    <div class="swiper testimonial-slider">
                        <div class="swiper-wrapper">
                                                        <!-- Slide 1 -->
                            <div class="swiper-slide">
                                <div class="testimonial-card">
                                    <div class="testimonial-icon">
                                        <img src="assets/images/testimonial-coma.svg" alt="Testimonial Quote">
                                    </div>
                                    <div class="testimonial-content">
                                        <h6>Visible results in just 3 sessions. Staff is super professional.</h6>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dui neque, sodales ut vestibulum vel, lobortis non odio. ut vestibulum vel, lobortis non </p>
                                    </div>
                                    <div class="testimonial-author">
                                        <div class="author-img">
                                            <img src="assets/images/testimonial-author-img-1.png" alt="Jaydon Aminoff">
                                        </div>
                                        <div class="author-name">
                                            <h4>Jaydon Aminoff</h4>
                                            <p>Laser Hair Removal Client</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Slide 3 -->
                            <div class="swiper-slide">
                                <div class="testimonial-card">
                                    <div class="testimonial-icon">
                                        <img src="assets/images/testimonial-coma.svg" alt="Testimonial Quote">
                                    </div>
                                    <div class="testimonial-content">
                                        <h6>Visible results in just 3 sessions. Staff is super professional.</h6>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dui neque, sodales ut vestibulum vel, lobortis non odio. ut vestibulum vel, lobortis non </p>
                                    </div>
                                    <div class="testimonial-author">
                                        <div class="author-img">
                                            <img src="assets/images/testimonial-author-img-1.png" alt="Jaydon Aminoff">
                                        </div>
                                        <div class="author-name">
                                            <h4>Jaydon Aminoff</h4>
                                            <p>Laser Hair Removal Client</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Slide 3 -->
                            <div class="swiper-slide">
                                <div class="testimonial-card">
                                    <div class="testimonial-icon">
                                        <img src="assets/images/testimonial-coma.svg" alt="Testimonial Quote">
                                    </div>
                                    <div class="testimonial-content">
                                        <h6>Visible results in just 3 sessions. Staff is super professional.</h6>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dui neque, sodales ut vestibulum vel, lobortis non odio. ut vestibulum vel, lobortis non </p>
                                    </div>
                                    <div class="testimonial-author">
                                        <div class="author-img">
                                            <img src="assets/images/testimonial-author-img-1.png" alt="Jaydon Aminoff">
                                        </div>
                                        <div class="author-name">
                                            <h4>Jaydon Aminoff</h4>
                                            <p>Laser Hair Removal Client</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Slide 4 -->
                            <div class="swiper-slide">
                                <div class="testimonial-card">
                                    <div class="testimonial-icon">
                                        <img src="assets/images/testimonial-coma.svg" alt="Testimonial Quote">
                                    </div>
                                    <div class="testimonial-content">
                                        <h6>Visible results in just 3 sessions. Staff is super professional.</h6>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin dui neque, sodales ut vestibulum vel, lobortis non odio. ut vestibulum vel, lobortis non </p>
                                    </div>
                                    <div class="testimonial-author">
                                        <div class="author-img">
                                            <img src="assets/images/testimonial-author-img-1.png" alt="Jaydon Aminoff">
                                        </div>
                                        <div class="author-name">
                                            <h4>Jaydon Aminoff</h4>
                                            <p>Laser Hair Removal Client</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <!-- Navigation -->
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>

                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- ================= FAQ Section START ================= -->
    <section class="faq-section section">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h2 class="h2-title">
                        Frequently Asked <span>Questions</span>
                    </h2>
                </div>

                <div class="col-lg-8 mx-auto">
                    <div class="faq-item">
                        <div class="faq-question">
                            <p>Is laser hair removal permanent?</p>
                            <span class="icon"><img src="assets/images/faq-arrow-icon.svg" alt="FAQ Icon"></span>
                        </div>
                        <div class="faq-answer">
                            <p>Laser hair removal significantly reduces hair growth, but maintenance sessions may be required.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question">
                            <p>Is it painful?</p>
                            <span class="icon"><img src="assets/images/faq-arrow-icon.svg" alt="FAQ Icon"></span>
                        </div>
                        <div class="faq-answer">
                            <p>Most people experience mild discomfort similar to a rubber band snap.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question">
                            <p>How many sessions are required?</p>
                            <span class="icon"><img src="assets/images/faq-arrow-icon.svg" alt="FAQ Icon"></span>
                        </div>
                        <div class="faq-answer">
                            <p>Typically 6-8 sessions are needed depending on hair type and area.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question">
                            <p>Any side effects?</p>
                            <span class="icon"><img src="assets/images/faq-arrow-icon.svg" alt="FAQ Icon"></span>
                        </div>
                        <div class="faq-answer">
                            <p>Temporary redness or irritation may occur but usually subsides quickly.</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
</main>
<?php include 'footer.php'; ?>
