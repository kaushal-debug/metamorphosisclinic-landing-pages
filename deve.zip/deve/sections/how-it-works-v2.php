<section class="section how-works-section v2">
    <div class="container">
        <div class="row">
            <!-- Heading -->
            <div class="col-12">
                <div class="section-header text-center">
                    <h2 class="h2-title">About <span>Fat Loss Treatment</span></h2>
                </div>
            </div>
            <!-- Left Content (Steps) -->
            <div class="col-lg-6 order-2 order-lg-1 step-card-wrapper">
                <div class="steps-card">
                    <div class="steps-wrap">
                        <div class="steps">
                            <h5 class="step-title"><span>Crystal Pro</span></h5>
                            <p>Permanently eliminate stubborn fat through controlled cooling. It triggers a natural process called apoptosis (cell death), leading to a<strong> 20% to 30% reduction</strong> of fat in the treated area after a single session without needles, incision or anesthesia. Treats 3-4 body parts simultaneously. Zero down time. Targets specific areas such as <strong>abdomen, love handles, double chin, jawline, thighs, knees, arms, bra-folds and back fat.</strong></p>
                        </div>
                        <div class="steps">
                            <h5 class="step-title"><span>Ozempic </span></h5>
                            <p><strong>Ozempic (semaglutide)</strong> is a once-weekly prescription injection primarily used to manage type 2 diabetes. It works by mimicking a <strong>natural hormone (GLP-1)</strong> that regulates blood sugar and appetite.</p>
                        </div>
                        <div class="steps">
                            <h5 class="step-title"><span>Mounjaro</span></h5>
                            <p><strong>Mounjaro (tirzepatide)</strong> is a prescription injectable for type 2 diabetes, often used off-label for weight management in adults. It works by mimicking <strong>GLP-1 and GIP</strong> hormones to improve glycemic control and promote weight loss. A dual aganist (GLP-1 and GIP) that increases insulin, reduces liver glucose production, and slows gastric emptying to increase satiety.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Right Image -->
            <div class="col-lg-6 order-1 order-lg-2">
                <div class="image-box">
                    <img src="assets/images/How-LHR-Works.webp" alt="Laser Treatment">
                </div>
            </div>
        </div>
        <!-- Bottom Labels -->

        <div class="row benefits">
            <div class="col-lg-6 benefit blue"><p>Effective Weight Loss</p></div>
            <div class="col-lg-6 benefit pink"><p>Targeted Fat Reduction</p></div>
        </div>
    </div>
</section>