<section class="section how-works-section v1">
    <div class="container">
        <div class="row">
            <!-- Heading -->
            <div class="col-12">
                <div class="section-header text-center">
                    <h2 class="h2-title"> How <span>Laser Hair Reduction</span> Works </h2>
                </div>
            </div>
            <!-- Left Content (Steps) -->
            <div class="col-lg-6 order-2 order-lg-1 step-card-wrapper">
                <div class="steps-card">
                    <div class="step-item">
                        <div class="step-circle out">
                            <div class="step-circle in">01 <span>STEP</span></div>
                        </div>
                        <p>Consultation &amp; skin analysis</p>
                    </div>
                    <div class="step-item">
                        <div class="step-circle out">
                            <div class="step-circle in">02 <span>STEP</span></div>
                        </div>
                        <p>Customized laser settings based on your skin type</p>
                    </div>
                    <div class="step-item">
                        <div class="step-circle out">
                            <div class="step-circle in">03 <span>STEP</span></div>
                        </div>
                        <p>Targeted laser pulses destroy hair follicles</p>
                    </div>
                    <div class="step-item">
                        <div class="step-circle out">
                            <div class="step-circle in">04 <span>STEP</span></div>
                        </div>
                        <p>Gradual reduction over multiple sessions</p>
                    </div>
                </div>
            </div>
            <!-- Right Image -->
            <div class="col-lg-6 order-1 order-lg-2">
                <div class="image-box">
                    <img src="assets/images/How-LHR-Works.webp" alt="Laser Treatment">
                </div>
            </div>
        </div>
        <!-- Bottom Labels -->

        <div class="row benefits">
            <div class="col-lg-6 benefit blue"><p>No damage to surrounding skin</p></div>
            <div class="col-lg-6 benefit pink"><p>Minimal discomfort</p></div>
        </div>
    </div>
</section>