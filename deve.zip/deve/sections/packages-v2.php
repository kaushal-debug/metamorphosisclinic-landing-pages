<section class="laser-section section v2">
    <div class="laser-container container">
        
        <h2 class="laser-title pink-text">Affordable Fat Loss Packages</h2>
        <p class="laser-subtitle subt">Simple and flexible per-user pricing</p>

        <div class="row g-3 justify-content-center">
            <div class="col-md-4">
                <div class="package-card">
                    <h4 class="package-title">Crystal Pro</h4>
                    <h4 class="package-price pink-text">₹X,XXX</h4>
                </div>
            </div>

            <div class="col-md-4">
                <div class="package-card">
                    <h4 class="package-title">Ozempic</h4>
                    <h4 class="package-price pink-text">₹X,XXX</h4>
                </div>
            </div>
            <div class="col-md-4">
                <div class="package-card">
                    <h4 class="package-title">Mounjaro</h4>
                    <h4 class="package-price pink-text">₹X,XXX</h4>
                </div>
            </div>
        </div>

        <a href="#contact-section" class="btn-primary">GET PRICING FOR YOUR AREA</a>

    </div>
</section>