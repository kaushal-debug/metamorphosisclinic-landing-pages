<!-- ================= Contact Section START ================= -->
<section class="contact-section section" id="contact-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <h2 class="h2-title text-center">
                    Get Your <span>Personalized Laser Plan</span>
                </h2>
            </div>
        </div>
        <div class="row justify-content-center form-row">
            <div class="col-lg-6">
                <div class="contact-image">
                    <img src="assets/images/contact-side-img.png" alt="Contact Image">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="contact-card">
                    <form class="contact-form" id="contactForm">

                        <div class="row">
                            <!-- Name -->
                            <div class="col-12">
                                <div class="form-group">
                                    <!-- <label for="name">Your Name*</label> -->
                                    <input 
                                        type="text" 
                                        id="name" 
                                        name="name" 
                                        placeholder="Full Name*" 
                                        required
                                    >
                                </div>
                            </div>
                            <!-- Email -->
                            <div class="col-12">
                                <div class="form-group">
                                    <!-- <label for="email">Email*</label> -->
                                    <input 
                                        type="email" 
                                        id="email" 
                                        name="email" 
                                        placeholder="Email*"
                                        required
                                    >
                                </div>
                            </div>

                            <!-- Phone -->
                            <div class="col-12">
                                <div class="form-group">
                                    <!-- <label for="phone">Phone No.*</label> -->
                                    <input 
                                        type="tel" 
                                        id="phone" 
                                        name="phone" 
                                        placeholder="Phone No.*" 
                                        required
                                    >
                                </div>
                            </div>

                            <!-- Location -->
                            <div class="col-12">
                                <div class="form-group">
                                    <!-- <label>Select Location*</label> -->
                                    <select
                                        id="location" 
                                        name="location" 
                                        required
                                        >
                                        <option>Select Location*</option>
                                        <option value="Mulund">Mulund</option>
                                        <option value="Powai">Powai</option>
                                        <option value="Ghatkopar">Ghatkopar</option>
                                        <option value="Bandra">Bandra</option>
                                        <option value="Andheri">Andheri</option>
                                        <option value="Vashi">Vashi</option>
                                        <option value="Charni Road">Charni Road</option>
                                        <option value="Greater Kailash">Greater Kailash</option>
                                        <option value="Green Park">Green Park</option>
                                    </select>
                                </div>
                            </div>
                            <!-- Button -->
                            <div class="col-12 text-center">
                                <input type="hidden" name="treatment" value="Laser Hair Reduction" id="treatment">
                                <button type="submit" class="btn-primary">
                                    BOOK CONSULTATION
                                </button>
                                <div id="formMessage" class="form-message"></div>
                            </div>
                        </div>
                    </form>
                    <div id="formLoader" class="form-loader">
                        <div class="spinner"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ================= Contact Section END ================= -->
