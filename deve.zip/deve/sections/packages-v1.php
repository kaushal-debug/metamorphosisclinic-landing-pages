<!-- ================= Packages Section START ================= -->
<section class="laser-section section v1">
    <div class="laser-container container">
        <h2 class="laser-title pink-text">Affordable Laser Packages</h2>
        <p class="laser-subtitle subt">Simple and flexible per-user pricing</p>
        <div class="row g-3 justify-content-center">

            <!-- Underarms -->
            <div class="col-md-4">
                <div class="package-card">
                    <div class="package-title">
                        <img src="./assets/images/package-underarms.svg" class="icon" alt="">
                    Underarms</div>
                    <div class="package-comb">
                        <div class="package-session">
                            <img src="./assets/images/package-check-box.svg" class="icon-2" alt=""> 6-8 Sessions</div>
                        <div class="package-price pink-text">₹9,000/session</div>
                    </div>
                </div>
            </div>

            <!-- Full Arms -->
            <div class="col-md-4">
                <div class="package-card">
                    <div class="package-title">
                        <img src="./assets/images/package-arms.svg" class="icon" alt="">
                        Full Arms</div>
                    <div class="package-comb">
                        <div class="package-session">
                            <img src="./assets/images/package-check-box.svg" class="icon-2" alt=""> 6-8 Sessions</div>
                        <div class="package-price pink-text">₹8,000/session</div>
                    </div>
                </div>
            </div>

            <!-- Full Body -->
            <div class="col-md-4">
                <div class="package-card">
                    <div class="package-title">
                        <img src="./assets/images/package-body.svg" class="icon" alt="">
                        Full Body</div>
                    <div class="package-comb">
                        <div class="package-session">
                            <img src="./assets/images/package-check-box.svg" class="icon-2" alt=""> 6-8 Sessions</div>
                        <div class="package-price pink-text">₹10,000/session</div>
                    </div>
                </div>
            </div>

        </div>
        <a href="#contact-section" class="btn-primary">GET PRICING FOR YOUR AREA</a>
    </div>
</section>
<!-- ================= Packages Section END ================= -->
